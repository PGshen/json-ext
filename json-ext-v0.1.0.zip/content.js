var e=2,t=`__json_ext_overlay_root__`,n=`__json_ext_overlay_style__`,r=`intercept`;function i(){if(window.top!==window)return null;let t=document.contentType.toLowerCase(),n=document.body?.innerText?.trim();if(!n||n.length<e)return null;let r=t.includes(`application/json`)||t.includes(`text/json`),i=n.startsWith(`{`)&&n.endsWith(`}`)||n.startsWith(`[`)&&n.endsWith(`]`);if(!r&&!i)return null;try{return JSON.parse(n),n}catch{return null}}function a(e){return`${chrome.runtime.getURL(`index.html`)}?mode=${r}&sourceUrl=${encodeURIComponent(e)}`}function o(){if(document.getElementById(n))return;let e=document.createElement(`style`);e.id=n,e.textContent=`
#${t} {
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  background: #ffffff;
}
#${t} iframe {
  width: 100%;
  height: 100%;
  border: 0;
  display: block;
}
#${t} .json-ext-close {
  position: absolute;
  top: 12px;
  right: 12px;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 1px solid #d0d7de;
  border-radius: 8px;
  background: #ffffff;
  cursor: pointer;
  font-size: 20px;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: #24292f;
  z-index: 1;
  transition: background-color 0.18s ease, border-color 0.18s ease, color 0.18s ease;
}
#${t} .json-ext-close:hover {
  background: #f6f8fa;
}
@media (prefers-color-scheme: dark) {
  #${t} .json-ext-close {
    border-color: #334155;
    background: #0f172a;
    color: #e2e8f0;
  }
  #${t} .json-ext-close:hover {
    background: #111f3d;
  }
}
`,document.documentElement.appendChild(e)}function s(e){if(document.getElementById(t))return;o();let n=document.documentElement.style.overflow;document.documentElement.style.overflow=`hidden`;let r=document.createElement(`div`);r.id=t;let i=document.createElement(`button`);i.type=`button`,i.className=`json-ext-close`,i.setAttribute(`aria-label`,`返回原页面`),i.textContent=`×`;let a=document.createElement(`iframe`);a.src=e,a.title=`JSON-Ext`;let s=()=>{r.remove(),document.documentElement.style.overflow=n,window.removeEventListener(`keydown`,c,!0)},c=e=>{e.key===`Escape`&&(e.preventDefault(),s())};i.addEventListener(`click`,s),window.addEventListener(`keydown`,c,!0),r.appendChild(i),r.appendChild(a),document.documentElement.appendChild(r)}i()&&s(a(location.href));